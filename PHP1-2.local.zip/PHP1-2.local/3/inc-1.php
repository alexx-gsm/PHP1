<?php

$var = 'Hello from include';

function func()  {
    return;
}

return $var;