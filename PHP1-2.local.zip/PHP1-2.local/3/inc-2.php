<?php

$var = 'Hello from include №2';

function func_2()  {
    return;
}